import { render, screen } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import React from 'react';
import App from './App';

jest.mock('axios', () => ({
  get: jest.fn(),
  post: jest.fn(),
}));

test('renders homepage correctly', () => {
  render(
    <MemoryRouter initialEntries={['/']}>
      <App />
    </MemoryRouter>
  );

  const textElement = screen.getByText(/welcome to monito pet shop/i);
  expect(textElement).toBeInTheDocument();
});

test('renders small dog page correctly', () => {
  render(
    <MemoryRouter initialEntries={['/dog/smalldog']}>
      <App />
    </MemoryRouter>
  );

  const textElement = screen.getByText(/small dog section/i);
  expect(textElement).toBeInTheDocument();
});